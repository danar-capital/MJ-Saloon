# MJ Team Android demo

This directory contains the Trusted Web Activity wrapper for the MJ Team PWA.
It launches `https://mj-saloon-review.danarcapital9.chatgpt.site/staff?app=1`
with application ID `com.danarcapital.mjteam.demo`.

The release keystore, passwords, APK, and AAB files are intentionally excluded
from source control. GitHub Actions produces an aligned unsigned APK; final
signing is performed outside the repository with the dedicated demo key whose
SHA-256 fingerprint is published in `public/.well-known/assetlinks.json`.
